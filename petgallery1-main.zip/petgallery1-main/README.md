**Flask Animal-Project**
=====================================================================================
💻program Introduction
--------------------------------------------------------------------------------------
* ##### beacuse many people raising pets are increasing recently, so I create this website for users who can share their knowledge about pets and gallery.

⏱️duration of development
--------------------------------------------------------------------------------------
* ##### 24.7.15 ~ 24. 8.9


⚙️development environment
--------------------------------------------------------------------------------------
* ##### Python
* ##### IDE:3.10
* ##### Framworkd:Flask
* ##### Datebase:Sqlite


🔍Key Features
--------------------------------------------------------------------------------------
* ##### membership
* ##### login
* ##### logout
* ##### gallery
* ##### video
* ##### board
* ##### chat window

📌Grid
--------------------------------------------------------------------------------------

* #### 1.installation
   >##### Requirement 
   >##### requirements.txt Reference
* #### 2. stacks
   >##### Environmnet: 
    <img src ="https://github.com/user-attachments/assets/b64d7eed-9897-425d-a6f1-5673adcd34d2" width=50px, higth=50px/ >
    <img src ="https://github.com/user-attachments/assets/b90780ab-687b-40c3-9440-af09a504dd3f" width=50px, higth=50px/ >
    <img src ="https://github.com/user-attachments/assets/cdfa97ca-da7d-481f-819e-ce7cc73ad13e" width=50px, higth=50px/ >

   >#### Developement
    <img src ="https://github.com/user-attachments/assets/c678e46e-bd3c-4289-a2e8-fa0cfe6de732" width=50px, higth=50px/>
    <img src ="https://github.com/user-attachments/assets/410371fa-d19a-4be2-a8c7-a39b99292d7f" width=50px, higth=50px>
    <img src ="https://github.com/user-attachments/assets/9e7d697d-450e-4003-8725-53309c0d71b2" width=50px, higth=50px/>
    <img src =" https://github.com/user-attachments/assets/eda2b966-d858-4d85-8de4-da91ae27ba56" width=50px, higth=50px/>
