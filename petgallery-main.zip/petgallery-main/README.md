**Flask Animal-Project**
=====================================================================================
💻program Introduction
--------------------------------------------------------------------------------------
* ##### beacuse many people raising pets are increasing recently, so I create this website for users who can share their knowledge about pets and gallery.

⏱️duration of development
--------------------------------------------------------------------------------------
* ##### 24.7.15 ~ 24. 8.9

📌Language used
--------------------------------------------------------------------------------------
* ##### Python 3.10
* ##### Freamwork:Flask
* ##### Datebase:Sqlite
* ##### flask
* ##### HTML
* ##### CSS
* ##### javascript
* ##### Ajax
* ##### jQuery
* ##### Socket.IO
* ##### AWS
* ##### canva
* ##### photoshop
  
Library
--------------------------------------------------------------------------------------
* #### Git/GitHub
* #### django-extensions


🔍Key Features
--------------------------------------------------------------------------------------
* ##### membership
* ##### login
* ##### logout
* ##### gallery
* ##### video
* ##### board
* ##### chat window
* ##### Membership Withdrawal
* ##### Information

